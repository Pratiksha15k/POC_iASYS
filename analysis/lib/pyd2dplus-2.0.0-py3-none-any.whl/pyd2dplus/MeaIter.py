import requests
from pyd2dplus import brix_pb2

class MeaIter:
    def __init__(self,dict_mea,auth_key):
        self.dict_mea = dict_mea
        self.auth_key = auth_key
        self.iterObj = []
        for key, value in self.dict_mea.items():
            obj = MeaBulkIter(key,value,self.auth_key)
            self.iterObj.append(obj)

    def __iter__(self):
        return self

    def __next__(self):
        try:
            val = []
            delet_obj = []
            for obj in self.iterObj:
                try:
                    if obj.has_next():
                        r = next(obj)
                        for result in r.measurements:
                            val.append(result)
                    if not obj.has_next():
                        delet_obj.append(obj)
                except Exception as e:
                    print(e)
            for ob in delet_obj:
                self.iterObj.remove(ob)
        except Exception as e:
            print(e)
        return val

    def has_next(self):
        return len(self.iterObj) != 0

class MeaBulkIter:
    def __init__(self,mea_url,mea_keys,auth_key):
        self.mea_url=mea_url
        self.mea_keys = mea_keys
        self.auth_key = auth_key
        self.cursor = 0
        self.mea_len = len(mea_keys)

    def __iter__(self):
        return self

    def __next__(self):
        try:
            val = {}
            if self.cursor == 0:
                val = getMeasurements(self.mea_url, self.mea_keys, self.auth_key)
            else:
                mea_next_keys = []
                for i in range(self.cursor,len(self.mea_keys)):
                    mea_next_keys.append(self.mea_keys[i])
                val = getMeasurements(self.mea_url,mea_next_keys, self.auth_key)
            if val.partial_result:
                if self.cursor == 0:
                    self.cursor = len(val.measurements)
                else:
                    self.cursor = self.cursor + len(val.measurements)
            else:
                self.cursor = len(self.mea_keys)
        except Exception as e:
            self.cursor=0
            self.mea_len=0
            print(e)
        return val

    def has_next(self):
        return self.cursor != self.mea_len;

def getMeasurements(url_str,mea_keys,auth_key):
    try:
        headers = {'Authorization': auth_key}
        bulk_mea_url = url_str + '/measurements/bulk'
        response = requests.post(bulk_mea_url, json=mea_keys, headers=headers)
        r = brix_pb2.Results()
        r.ParseFromString(response.content)
        return r
    except Exception as e:
        raise Exception(e)