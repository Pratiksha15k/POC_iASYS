class Measurement:
    def __init__(self):
        self.url = ''
        self.name = ''
        self.channel_names = []
        self.out_put_tags = []
        self.out_put_data_names = []

    def set_url(self, url):
        self.url = url

    def set_name(self, name):
        self.name = name

    def set_channel_names(self,channel_names):
        self.channel_names = channel_names

    def set_out_put_tags(self,out_put_tags):
        self.out_put_tags = out_put_tags

    def set_out_put_data_names(self,out_put_data_names):
        self.out_put_data_names = out_put_data_names

    def get_url(self):
        return self.url

    def get_name(self):
        return self.name

    def get_channel_names(self):
        return self.channel_names

    def get_out_put_tags(self):
        return self.out_put_tags

    def get_out_put_data_names(self):
        return self.out_put_data_names
