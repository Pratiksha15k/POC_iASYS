import requests
import json
from urllib.parse import urlparse
import socket
from requests.auth import HTTPBasicAuth
import pandas as pd
import numpy as np
from pyd2dplus.MeaIter import MeaIter
from pyd2dplus import brix_pb2
from pyd2dplus.Measurement import Measurement

def connect(url):
    try:
        urlp = urlparse(url)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((urlp.hostname, int(urlp.port)))
        authentication = requests.get(url + "/systems/hodsauthkey")
        authdata = json.loads(authentication.text)
        authkey = authdata['data']
        return D2DPlus(url,authkey)
    except Exception as e:
        raise Exception('Could not connect to server.Please check url is correct or confirm server is running additional msg:'+ str(e))

class D2DPlus:
    def __init__(self,url,authKey):
        self.url = url
        self.authKey = authKey

    def getTagNoBySearch(self, search_criteria):
        try:
            url_str = self.url + "/tagno/search"
            response = requests.post(url_str,json=search_criteria)
            data = json.loads(response.text)
        except Exception as e:
            raise Exception(e)
        return data

    def getMeasurements(self,tag_no_id):
        try:
            url_str = self.url + "/tagnos/tagnokey/" + str(tag_no_id)+"/measurements"
            response = requests.get(url_str)
            data = json.loads(response.text)
            return data
        except Exception as e:
            raise Exception(e)

    def getMeasurementChannelInfo(self,measurement_url):
        try:
            headers = {'Authorization': self.authKey}
            response = requests.get(measurement_url, headers=headers)
            data = json.loads(response.text)
            return data
        except Exception as e:
            raise Exception(e)

    def getMeasurementDataByURL(self,measurement_url):
        try:
            headers = {'Authorization': self.authKey}
            response = requests.get(measurement_url, headers=headers)
            data = json.loads(response.text)
            return data
        except Exception as e:
            raise Exception(e)

    def getChannelData(self,channel_url):
        try:
            headers = {'Authorization': self.authKey}
            response = requests.get(channel_url, headers=headers)
            data = json.loads(response.text)
            return data
        except Exception as e:
            raise Exception(e)

    def transferResult(self,test_obj,job_id):
        try:
            url_str = self.url + "/jobmanager/atfx/jobid/" + str(job_id)
            if isinstance(test_obj,brix_pb2.Results):
                headers = {'acceptType': 'application/x-protobuf','Content-Type': 'application/x-protobuf'}
                response = requests.post(url_str, data=test_obj.SerializeToString(),headers=headers)
                r = brix_pb2.Results()
                r.ParseFromString(response.content)
                return r
            else:
                response = requests.post(url_str, json=test_obj)
                data = json.loads(response.text)
                return data
        except Exception as e:
            print(e)
            raise Exception(e)

    def transferResultByFTP(self,test_obj,ftp_detail):
        try:
            test_obj['ftpDetails']=ftp_detail
            url_str = self.url + "/jobmanager/atfx/ftp"
            response = requests.post(url_str, json=test_obj)
            data = json.loads(response.text)
            return data
        except Exception as e:
            print(e)
            raise Exception(e)


    def generateAndDownloadAtfx(self,test_obj,file_location):
        try:
            retun_data={}
            url_str = self.url + "/jobmanager/generateatfx"
            response = requests.post(url_str, json=test_obj)
            data = json.loads(response.text)
            if data['errorCode'] == 1:
                file_download_name = data['data']['outPutFileName']
                url_str = self.url + "/jobmanager/downloadatfx/" + str(file_download_name)
                response = requests.get(url_str)
                with open(file_location + "/" + file_download_name, 'wb') as f:
                    f.write(response.content)
                retun_data['message'] = 'ATFX generated successfully.'
                retun_data['errorCode'] = 1
                data_part={
                    'outPutFileName':file_download_name
                }
                retun_data['data']=data_part
            else:
                retun_data['message']= data['message']
                retun_data['errorCode'] = data['errorCode']

            return retun_data
        except Exception as e:
            raise Exception(e)

    def updateJobStatus(self,job_id,message):
        try:
            job_dict = {}
            job_dict['message'] = message
            url_str = self.url + "/jobmanager/jobstatus/jobid"+str(job_id)
            response = requests.post(url_str, json=job_dict)
            data = json.loads(response.text)
            return data
        except Exception as e:
            raise Exception(e)

    def jsonToPanda(self,measurement_data):
        try:
            data_fram = {}
            for mea in measurement_data:
                columns_tuple = []
                columns_tuple.append(mea['name'])
                columns_tuple.append(mea['unit'])
                columns_tuple.append(mea['dataType'])
                col = tuple(columns_tuple)
                val = mea['values']
                if val != None:
                    if len(val) != 0:
                        data_fram[col] = val

            df = pd.DataFrame.from_dict(data_fram, orient='index')
            df = df.transpose()
            return df
        except Exception as e:
            print(e)
            raise Exception(e)

    def getBrixWebServiceContext(self,measurement_url):
        try:
            headers = {'Authorization': self.authKey}
            hods_url=measurement_url.split("measurements")[0]
            return Brix(hods_url)
        except Exception as e:
            raise Exception(e)

    def getSubmatrixlist(self,brix_context,measurement_id):
        try:
            sub_matrix_url = brix_context.url + "measurements/measurementkey/" + str(measurement_id)+"/channelgroups"
            headers = {'Authorization': self.authKey}
            response = requests.get(sub_matrix_url, headers=headers)
            data = json.loads(response.text)
            return data
        except Exception as e:
            raise Exception(e)

    def getSubmatrixData(self,brix_context,measurement_id,sub_matrix_id):
        try:
            sub_matrix_url = brix_context.url + "mesurements/measurementkey/" + str(measurement_id)+"/channelgroups/" + str(sub_matrix_id)+"/channels/channeldata"
            headers = {'Authorization': self.authKey}
            response = requests.get(sub_matrix_url, headers=headers)
            data = json.loads(response.text)
            return data
        except Exception as e:
            raise Exception(e)

    def getBulkMeasurementByURL(self,measurement_urls):
        mea_keys = {};
        lis_du = []
        try:
            for mea in measurement_urls:
                urlp = urlparse(mea)
                path = urlp.path.split('/')
                url = urlp[0] + '://' + urlp[1]+'/'+path[1]+'/'+path[2]
                if url in mea_keys:
                    list_keys = mea_keys[url]
                    list_keys.append(path[5])
                    lis_du.append(path[5])
                else:
                    mea_list = []
                    mea_list.append(path[5])
                    mea_keys[url] = mea_list
            return MeaIter(mea_keys,self.authKey)
        except Exception as e:
            raise Exception(e)

    def resultToPanda(self,result):
        data_fram = {}
        try:
            names_arr = []
            unit_arr = []
            data_arr = []
            names = result.columns[0].string_array.values
            units = result.columns[1].string_array.values
            data_values = result.columns[3].unknown_arrays.values
            for name in names:
                names_arr.append(name)

            for unit in units:
                unit_arr.append(unit)

            for data_val in data_values:
                data_arr.append(data_val)
            cout = 0
            for name in names_arr:
                columns_tuple = []
                columns_tuple.append(name)
                columns_tuple.append(unit_arr[cout])
                val = None
                dataType = data_arr[cout].data_type
                if dataType == 1:
                    columns_tuple.append('STRING')
                    val = list(data_arr[cout].string_array.values)
                if dataType == 4:
                    columns_tuple.append('BOOLEAN')
                    val = list(data_arr[cout].boolean_array.values)
                if dataType == 2:
                    columns_tuple.append('SHORT')
                    val = list(data_arr[cout].long_array.values)
                if dataType == 5:
                    columns_tuple.append('BYTE')
                    val = list(data_arr[cout].byte_array.values)
                if dataType == 7:
                    columns_tuple.append('DOUBLE')
                    val = list(data_arr[cout].double_array.values)
                if dataType == 3:
                    columns_tuple.append('FLOAT')
                    val = list(data_arr[cout].float_array.values)
                if dataType == 6:
                    columns_tuple.append('LONG')
                    val = list(data_arr[cout].long_array.values)
                if dataType == 8:
                    columns_tuple.append('LONGLONG')
                    val = list(data_arr[cout].longlong_array.values)
                if dataType == 13:
                    columns_tuple.append('COMPLEX')
                    val = list(data_arr[cout].float_array.values)
                if dataType == 14:
                    columns_tuple.append('DCOMPLEX')
                    val = list(data_arr[cout].float_array.values)
                if dataType == 10:
                    columns_tuple.append('DATE')
                    val = list(data_arr[cout].string_array.values)
                cout = cout+1
                col = tuple(columns_tuple)
                if val != None:
                    if len(val) != 0:
                        data_fram[col] = val
            df = pd.DataFrame.from_dict(data_fram, orient='index')
            df = df.transpose()
            return df
        except Exception as e:
            raise Exception(e)

    def resultToJson(self, result):
        measurement_dict = {}
        try:
            names_arr = []
            unit_arr = []
            data_arr = []
            names = result.columns[0].string_array.values
            units = result.columns[1].string_array.values
            data_values = result.columns[3].unknown_arrays.values
            for name in names:
                names_arr.append(name)

            for unit in units:
                unit_arr.append(unit)

            for data_val in data_values:
                data_arr.append(data_val)
            measurement_dict['id'] = result.instance_id
            measurement_dict['mimeType'] = 'application/x-asam.AoMeasurement.MeaResult'
            measurement_dict['name'] = result.instance_name
            channel_list = []
            cout = 0
            for name in names_arr:
                channel = {}
                channel['name'] = name
                channel['unit'] = unit_arr[cout]
                val = None
                dataType = data_arr[cout].data_type
                if dataType == 1:
                    channel['datatype'] = 'STRING'
                    val = list(data_arr[cout].string_array.values)
                if dataType == 4:
                    channel['datatype'] = 'BOOLEAN'
                    val = list(data_arr[cout].boolean_array.values)
                if dataType == 2:
                    channel['datatype'] = 'SHORT'
                    val = list(data_arr[cout].long_array.values)
                if dataType == 5:
                    channel['datatype'] = 'BYTE'
                    val = list(data_arr[cout].byte_array.values)
                if dataType == 7:
                    channel['datatype'] = 'DOUBLE'
                    val = list(data_arr[cout].double_array.values)
                if dataType == 3:
                    channel['datatype'] = 'FLOAT'
                    val = list(data_arr[cout].float_array.values)
                if dataType == 6:
                    channel['datatype'] = 'LONG'
                    val = list(data_arr[cout].long_array.values)
                if dataType == 8:
                    channel['datatype'] = 'LONGLONG'
                    val = list(data_arr[cout].longlong_array.values)
                if dataType == 13:
                    channel['datatype'] = 'COMPLEX'
                    val = list(data_arr[cout].float_array.values)
                if dataType == 14:
                    channel['datatype'] = 'DCOMPLEX'
                    val = list(data_arr[cout].float_array.values)
                if dataType == 10:
                    channel['datatype'] = 'DATE'
                    val = list(data_arr[cout].string_array.values)
                channel['value'] = val
                channel_list.append(channel)
                cout = cout + 1
            measurement_dict['channel'] = channel_list
            return measurement_dict
        except Exception as e:
            raise Exception(e)


    def hasMoreData(self,mea):
        url_str = mea.self_url.split('measurements')
        try:
            isPartial_mea = False
            for res in mea.results:
                if res.partial_value:
                    isPartial_mea = True
            if isPartial_mea:
                for res in mea.results:
                    if res.partial_value:
                        old_data_Val = res.columns[3].unknown_arrays.values
                        isPartila = True
                        subMat = res
                        while isPartila:
                            value_start = subMat.values_start + subMat.values_count
                            sub_matrix_url = str(url_str[0]) + 'measurements/measurementkey/MeaResult:' + \
                                             str(mea.instance_id) + '/channelgroups/subMatrix:' + str(
                                subMat.instance_id) + '/channels/channeldata?start=' + str(value_start)
                            result = BrixUtility(self.url,self.authKey).getSubMatrixData(sub_matrix_url)
                            subMat = result.measurements[0].results[0]
                            if subMat.partial_value:
                                isPartila = True
                            else:
                                isPartila = False
                            new_data_values = subMat.columns[3].unknown_arrays.values
                            BrixUtility(self.url, self.authKey).mergeSubMatrix(old_data_Val,new_data_values)
            return mea
        except Exception as e:
            raise Exception(e)

    def getList(self,nodeLabel,attribute):
        try:
            url_str = self.url + "/list/nodelabel/" + str(nodeLabel) + "/attribute/"+ str(attribute)
            response = requests.get(url_str)
            data = json.loads(response.text)
            return data
        except Exception as e:
            raise Exception(e);

    def getMeasurementBySearch(self, search_criteria):
        try:
            url_str = self.url + "/measurement/search"
            response = requests.post(url_str,json=search_criteria)
            data = json.loads(response.text)
        except Exception as e:
            raise Exception(e)
        return data

    def getResultByCypher(self, query):
        print('')

    #list measurement class
    def combineTagNoMeasurement(self, test_order_id,test_name,list_measurement,ftp_dct):
        try:
            if not isinstance(list_measurement, list):
                raise Exception('invalid measurement list')
            tag_no_mea ={}
            tag_no_mea['testorderid'] = test_order_id
            tag_no_mea['filetransfermode'] = ftp_dct
            tag_no_mea['testname'] = test_name
            lst_measurements = []
            for mea in list_measurement:
                if isinstance(mea, Measurement):
                    for (out_put_tag,out_put_data_name) in zip(mea.get_out_put_tags(),mea.get_out_put_data_names()):
                        mea_obj = {}
                        mea_obj['measurementURL'] = mea.get_url()
                        mea_obj['name'] = mea.get_name()
                        mea_obj['outputTagNo'] = out_put_tag
                        mea_obj['outTagDataName'] = out_put_data_name
                        lst_measurements.append(mea_obj)
            tag_no_mea['measurements'] = lst_measurements
            url_str = self.url + "/jobmanager/atfx/combine/tagnos"
            print(tag_no_mea)
            response = requests.post(url_str, json=tag_no_mea)
            data = json.loads(response.text)
            return data
        except Exception as e:
            raise Exception(e)

    def separateTagNoMeasurement(self, test_order_id,list_measurement,ftp_dct):
        print('')

    def getChannelData(self, measurement_url,channel_list):
        print('')


class BrixUtility:
    def __init__(self,url,authKey):
        self.url = url
        self.authKey = authKey

    def getSubMatrixData(self, url):
        try:
            headers = {'Authorization': self.authKey,'acceptType':'application/x-protobuf'}
            response = requests.get(url, headers=headers)
            r = brix_pb2.Results()
            r.ParseFromString(response.content)
            return r;
        except Exception as e:
            raise Exception(e)

    def mergeSubMatrix(self,old_data_Val,new_data_values):
        try:
            for (o_val, n_val) in zip(old_data_Val, new_data_values):
                if n_val.data_type == 1:
                    n_string_arr = list(n_val.string_array.values)
                    for strr in n_string_arr:
                        o_val.string_array.values.append(strr)
                if n_val.data_type == 2:
                    n_long_arr = list(n_val.long_array.values)
                    for lon in n_long_arr:
                        o_val.long_array.values.append(lon)
                if n_val.data_type == 3:
                    n_float_arr = list(n_val.float_array.values)
                    for flo in n_float_arr:
                        o_val.float_array.values.append(flo)
                if n_val.data_type == 4:
                    n_boolean_arr = list(n_val.boolean_array.values)
                    for boo in n_boolean_arr:
                        o_val.boolean_array.values.append(boo)
                if n_val.data_type == 5:
                    n_byte_arr = list(n_val.byte_array.values)
                    for byt in n_byte_arr:
                        o_val.byte_array.values.append(byt)
                if n_val.data_type == 6:
                    n_long_arr = list(n_val.long_array.values)
                    for lon in n_long_arr:
                        o_val.long_array.values.append(lon)
                if n_val.data_type == 7:
                    n_double_arr = list(n_val.double_array.values)
                    for dou in n_double_arr:
                        o_val.double_array.values.append(dou)
                if n_val.data_type == 8:
                    n_longlong_arr = list(n_val.longlong_array.values)
                    for lonlon in n_longlong_arr:
                        o_val.longlong_array.values.append(lonlon)
                if n_val.data_type == 10:
                    n_string_arr = list(n_val.string_array.values)
                    for strr in n_string_arr:
                        o_val.string_array.values.append(strr)
                if n_val.data_type == 13:
                    n_float_arr = list(n_val.float_array.values)
                    for flo in n_float_arr:
                        o_val.float_array.values.append(flo)
                if n_val.data_type == 14:
                    n_double_arr = list(n_val.double_array.values)
                    for doub in n_double_arr:
                        o_val.double_array.values.append(doub)
        except Exception as e:
            raise Exception(e)


class Brix:
    def __init__(self,url):
        self.url = url

