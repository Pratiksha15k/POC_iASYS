import D2DPlus
import json
import datetime
from pyd2dplus import brix_pb2
from pyd2dplus.Measurement import Measurement

def runscript(testdata):
    conn = D2DPlus.connect(testdata['d2dPlusServerUrl'])
    tag_no_lists = conn.getTagNoBySearch(testdata['searchFilters'])
    print(tag_no_lists)
    measurement_list = []
    for tag in tag_no_lists['data']:
        tag_no = tag['tagNoKey']
        measurements = conn.getMeasurements(tag_no)
        print(measurements)
        for mea in measurements['data']:
            print(mea)
            channels = conn.getMeasurementDataByURL(mea['measurementDataURL'])
            if channels['returncode'] == 1:
                df = conn.jsonToPanda(channels['data'])
                df_max = df.mean()
                mean_result = df_max.to_dict()
                measurement = perpare_measurment_data(mean_result)
                measurement_list.append(measurement)

    test_dict = {}
    test_dict['name'] = 'Test 1'
    test_dict['measurement'] = measurement_list
    print(measurement_list)
    result = conn.generateAtfx(test_dict,"D:/python")
    print(result)

def run_demo():
    searchFilters = {}
    searchFilters['projectCode'] = '2JA'
    tag_no_lists = D2DPlus.getTagNoBySearch(searchFilters)

# def perpare_measurment_data(mean_result):
#     measurement_dict = {}
#     measurement_dict['name'] = 'Measurement 1'
#     measurement_dict['mimeType'] = 'application/x-asam.AoMeasurement.MeaResult'
#     channel_list = []
#     for key, value in mean_result.items():
#         channel = {}
#         channel['name'] = key[0]
#         channel['unit'] = key[1]
#         channel['datatype'] ='DT_'+key[2]
#         data_arr = []
#         data_arr.append(value)
#         channel['value'] = data_arr
#         channel_list.append(channel)
#     measurement_dict['channel'] = channel_list
#     return measurement_dict

testdata = {
    'd2dPlusServerUrl' : 'http://172.16.111.34:8085/d2dplus/v1',
    'testOrderId' : 3181,
    'jobid' : 'a0f146ed-8b2e-4944-bf66-481c5de9471d',
    'searchFilters' : {
        'projectCode' : '2JA',
        'tagNos':['検証データ名003']
    },
}


def getList(testdata):
    conn = D2DPlus.connect(testdata['d2dPlusServerUrl'])
    data = conn.getList('Project','projectCode')
    print(data)

#getList(testdata)


def bulk_mea(testdata):
    conn = D2DPlus.connect(testdata['d2dPlusServerUrl'])
    #tag_no_lists = conn.getTagNoBySearch(testdata['searchFilters'])
    measurements = conn.getMeasurementDataByURL('http://172.16.48.108:8080/hods/v1/tests/testkey/Test:1684/measurements')
    measurement_list_key = []
    for mea in measurements['data']:
        measurement_list_key.append('http://172.16.48.108:8080/hods/v1/measurements/measurementkey/'+str(mea['measurementKey'])+'/channels/channeldata')

    print(len(measurement_list_key))
    start_time = datetime.datetime.now()
    itr = conn.getBulkMeasurementByURL(measurement_list_key)
    measureme_data_list=[]
    while itr.has_next():
        res = next(itr)
        print(len(res))
        # for mea in res:
        #     final_mea = conn.hasMoreData(mea)
        #     for result in final_mea.results:
        #         df = conn.resultToPanda(result)
        #         df_max = df.max()
        #         mean_result = df_max.to_dict()
        #         measureme_data_list.append(mean_result)
    # ddata = {}
    # ddata['data'] = measureme_data_list
    # with open('D:/python/data.json', 'w') as json_file:
    #     json.dump(ddata, json_file)
    end_time = datetime.datetime.now()
    print(end_time-start_time)
            # for ress in final_mea.results:
            #     val = ress.columns[3].unknown_arrays.values
            #     for m in val:
            #         if m.data_type == 1:
            #             print(len(list(m.string_array.values)))
            #         if m.data_type == 2:
            #             print(len(list(m.long_array.values)))
            #         if m.data_type == 3:
            #             print(len(list(m.float_array.values)))
            #         if m.data_type == 4:
            #             print(len(list(m.boolean_array.values)))
            #         if m.data_type == 5:
            #             print(len(list(m.byte_array.values)))
            #         if m.data_type == 6:
            #             print(len(list(m.long_array.values)))
            #         if m.data_type == 7:
            #             print(len(list(m.double_array.values)))
            #         if m.data_type == 8:
            #             print(len(list(m.longlong_array.values)))
            #         if m.data_type == 10:
            #             print(len(list(m.string_array.values)))
            #         if m.data_type == 13:
            #             print(len(list(m.float_array.values)))
            #         if m.data_type == 14:
            #             print(len(list(m.double_array.values)))


def mea_to_pandas(testdata):
    conn = D2DPlus.connect(testdata['d2dPlusServerUrl'])
    measurements = conn.getMeasurementDataByURL('http://172.16.48.174:8080/hods/v1/tests/testkey/Test:2026/measurements')
    measurement_data_url_list = []
    # for mea in measurements['data']:
    #     measurement_data_url_list.append('http://localhost:8087/brixloader/v1/measurements/measurementkey/'+str(mea['measurementKey'])+'/channels/channeldata')
    measurement_data_url_list.append('http://172.16.48.174:8080/hods/v1/measurements/measurementkey/MeaResult:81934/channels/channeldata')
    itr = conn.getBulkMeasurementByURL(measurement_data_url_list)
    list_measurement_proto = []
    while itr.has_next():
        meas = next(itr)
        for mea in meas:
            complete_mea = conn.hasMoreData(mea)
            for result in complete_mea.results:
                df = conn.resultToPanda(result)
                df_max = df.max()
                mean_result = df_max.to_dict()
                measurement = perpare_measurment_data(mean_result,'A','A')
                list_measurement_proto.append(measurement)

    # result = brix_pb2.Result()
    # name_col = brix_pb2.Result.Column()
    # name_col.name = 'name'
    # name_col.data_type = brix_pb2.DataTypeEnum.DT_STRING
    # name_col.string_array.values.append('AnalysisTestOrder')
    # test_order_col = brix_pb2.Result.Column()
    # test_order_col.name = 'testOrderId'
    # test_order_col.data_type = brix_pb2.DataTypeEnum.DT_STRING
    # test_order_col.string_array.values.append('1')
    # result.columns.append(name_col)
    # result.columns.append(test_order_col)
    # results = brix_pb2.Results()
    # results.results.append(result)
    # for mea in list_measurement_proto:
    #     results.measurements.append(mea)
    # conn.transferResult(results,'AAA')
    # print(results)
    test_dict = {}
    test_dict['name'] = 'AnalysisTestOrder'
    test_dict['testOrderId'] = 2061
    test_dict['measurement'] = list_measurement_proto
    ftp_dict = {}
    ftp_dict['ftphost']='172.16.48.174'
    ftp_dict['ftpport'] = '21'
    print('HIII')
    resss = conn.transferResultByFTP(test_dict,ftp_dict)
    print(resss)




def perpare_measurment_proto(mean_result,datanamevar,resultTagnovar):
    measurement = brix_pb2.Measurement()
    try:
        result = brix_pb2.Result()
        measurement.name = datanamevar
        measurement.description = resultTagnovar
        measurement.mime_type = 'application/x-asam.AoMeasurement.MeaResult'
        name_col = brix_pb2.Result.Column()
        name_col.name = 'name'
        name_col.data_type = brix_pb2.DataTypeEnum.DT_STRING
        unit_col = brix_pb2.Result.Column()
        unit_col.name = 'unit'
        unit_col.data_type = brix_pb2.DataTypeEnum.DT_STRING
        values_col = brix_pb2.Result.Column()
        values_col.name = 'values'
        unit_col.data_type = brix_pb2.DataTypeEnum.DT_UNKNOWN

        for key, value in mean_result.items():
            if value==None:
                continue
            name_col.string_array.values.append(key[0])
            unit_col.string_array.values.append(key[1])
            values_col.unknown_arrays.values.append(get_unknown_array(key[2], value))

        result.columns.append(name_col)
        result.columns.append(unit_col)
        result.columns.append(values_col)
        measurement.results.append(result)
    except Exception as e:
        print(e)
        raise Exception(e)
    return measurement



def get_unknown_array(data_type,values):
    unknow_col = brix_pb2.Result.Column.UnknownArray()
    try:
        if data_type == 'STRING':
            unknow_col.data_type = brix_pb2.DataTypeEnum.DT_STRING
            unknow_col.string_array.values.append(values)
        if data_type == 'SHORT':
            unknow_col.data_type = brix_pb2.DataTypeEnum.DT_SHORT
            unknow_col.long_array.values.append(values)
        if data_type == 'FLOAT':
            unknow_col.data_type = brix_pb2.DataTypeEnum.DT_FLOAT
            unknow_col.float_array.values.append(values)
        if data_type == 'BOOLEAN':
            unknow_col.data_type = brix_pb2.DataTypeEnum.DT_BOOLEAN
            unknow_col.boolean_array.values.append(values)
        if data_type == 'BYTE':
            unknow_col.data_type = brix_pb2.DataTypeEnum.DT_BYTE
            unknow_col.byte_array.values.append(values)
        if data_type == 'LONG':
            unknow_col.data_type = brix_pb2.DataTypeEnum.DT_LONG
            unknow_col.long_array.values.append(values)
        if data_type == 'DOUBLE':
            unknow_col.data_type = brix_pb2.DataTypeEnum.DT_DOUBLE
            unknow_col.double_array.values.append(values)
        if data_type == 'LONGLONG':
            unknow_col.data_type = brix_pb2.DataTypeEnum.DT_LONGLONG
            unknow_col.longlong_array.values.append(values)
        if data_type == 'DATE':
            unknow_col.data_type = brix_pb2.DataTypeEnum.DT_DATE
            unknow_col.string_array.values.append(values)
        if data_type == 'COMPLEX':
            unknow_col.data_type = brix_pb2.DataTypeEnum.DT_COMPLEX
            unknow_col.float_array.values.append(values)
        if data_type == 'DCOMPLEX':
            unknow_col.data_type = brix_pb2.DataTypeEnum.DT_DCOMPLEX
            unknow_col.double_array.values.append(values)
        return unknow_col
    except Exception as e:
        print(e)
        raise Exception(e)






def perpare_measurment_data(mean_result,datanamevar,resultTagnovar):
    measurement_dict = {}
    measurement_dict['name'] = datanamevar
    measurement_dict['mimeType'] = 'application/x-asam.AoMeasurement.MeaResult'
    measurement_dict['description'] =resultTagnovar
    channel_list = []
    for key, value in mean_result.items():
        channel = {}
        channel['name'] = key[0]
        channel['unit'] = key[1]
        channel['datatype'] ='DT_'+key[2]
        data_arr = []
        data_arr.append(value)
        channel['value'] = data_arr
        channel_list.append(channel)
    measurement_dict['channel'] = channel_list
    return measurement_dict



# get_unknown_array('STRING',None)
#mea_to_pandas(testdata)
#bulk_mea(testdata)

#runscript(testdata)


def combineTest(testdata):
    mea1 = Measurement()
    mea1.set_url('http://172.16.48.108:8080/hods/v1/measurements/measurementkey/MeaResult:62121/channels/channeldata')
    mea1.set_name('M1')
    out_put_tt = []
    out_put_tt.append('A05646')
    mea1.set_out_put_tags(out_put_tt)
    dd = []
    dd.append('vvxvxcv')
    mea1.set_out_put_data_names(dd)
    conn = D2DPlus.connect(testdata['d2dPlusServerUrl'])
    ftp_dict = {}
    ftp_dict['host']='172.16.48.174'
    ftp_dict['port'] = '21'
    ftp_dict['password'] = 'avalon'
    ftp_dict['ftp'] = 'avalon'
    ftp_dict['rootpath'] = '/home/avalon/hods/IASYS/ServerImporter/PendingFiles/'
    ftp_dict['username'] = 'avalon'
    mea_list = []
    mea_list.append(mea1)
    res = conn.combineTagNoMeasurement(100,'Test001',mea_list,ftp_dict)
    print(res)
combineTest(testdata)

